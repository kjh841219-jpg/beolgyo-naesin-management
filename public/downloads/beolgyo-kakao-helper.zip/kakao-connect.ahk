#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
SetTitleMatchMode 3
SetControlDelay 80
sendLock := 0

HelperVersion() {
    return "20261027-searchfocus4"
}
Status(value) {
    statusName := A_Args.Length = 1 && A_Args[1] = "--self-test" ? "self-test-status.txt" : "last-status.txt"
    file := FileOpen(A_ScriptDir "\" statusName, "w", "UTF-8")
    file.Write(FormatTime(, "yyyy-MM-dd HH:mm:ss") " [" HelperVersion() "] " value)
    file.Close()
}
Decode(value) {
    value := StrReplace(value, "+", " ")
    buf := Buffer(StrPut(value, "UTF-8"), 0)
    offset := 0, i := 1
    while i <= StrLen(value) {
        ch := SubStr(value, i, 1)
        if ch = "%" && RegExMatch(SubStr(value, i + 1, 2), "^[0-9a-fA-F]{2}$") {
            NumPut("UChar", Integer("0x" SubStr(value, i + 1, 2)), buf, offset)
            offset += 1, i += 3
        } else {
            size := StrPut(ch, "UTF-8") - 1
            temp := Buffer(size + 1)
            StrPut(ch, temp, "UTF-8")
            DllCall("RtlMoveMemory", "Ptr", buf.Ptr + offset, "Ptr", temp.Ptr, "UPtr", size)
            offset += size, i += 1
        }
    }
    return StrGet(buf, offset, "UTF-8")
}
FindRoom(title) {
    matches := []
    previousSetting := A_DetectHiddenWindows
    try {
        DetectHiddenWindows true
        for hwnd in WinGetList("ahk_exe KakaoTalk.exe") {
            if WinGetTitle("ahk_id " hwnd) != title
                continue
            editor := DllCall("GetDlgItem", "Ptr", hwnd, "Int", 1006, "Ptr")
            if editor && InStr(StrLower(WinGetClass("ahk_id " editor)), "richedit")
                matches.Push(hwnd)
        }
    } finally {
        DetectHiddenWindows previousSetting
    }
    if matches.Length > 1
        throw Error("같은 이름의 대화방이 여러 개입니다. 방 이름을 서로 다르게 해 주세요.")
    if matches.Length = 1 {
        if !DllCall("IsWindowVisible", "Ptr", matches[1])
            WinShow("ahk_id " matches[1])
        return matches[1]
    }
    return 0
}
FindMain() {
    ; Closing Kakao's main window usually hides it in the notification area.
    ; Match the logged-in main-view structure, not a hidden chat or login dialog.
    previousSetting := A_DetectHiddenWindows
    matches := []
    try {
        DetectHiddenWindows true
        for hwnd in WinGetList("ahk_exe KakaoTalk.exe") {
            if WinGetTitle("ahk_id " hwnd) = "카카오톡" && DllCall("GetDlgItem", "Ptr", hwnd, "Int", 132, "Ptr")
                matches.Push(hwnd)
        }
    } finally {
        DetectHiddenWindows previousSetting
    }
    if matches.Length > 1
        throw Error("카카오톡 메인창이 여러 개여서 안전하게 선택하지 못했습니다.")
    if matches.Length = 1 {
        WinShow("ahk_id " matches[1])
        return matches[1]
    }
    return 0
}
Activate(hwnd) {
    WinRestore("ahk_id " hwnd)
    WinActivate("ahk_id " hwnd)
    if !WinWaitActive("ahk_id " hwnd, , 2)
        throw Error("카카오톡 창을 활성화하지 못했습니다. 다른 창을 클릭하지 말고 다시 눌러 주세요.")
}
RequestQuery(uri) {
    ; Edge can canonicalize a custom-scheme host by adding a slash before ?.
    if !RegExMatch(Trim(uri), "i)^beolgyo-kakao://(?:compose|test|send)/?\?([^#]*)$", &parsed)
        throw Error("관리자페이지에서 전달한 연결 주소를 인식하지 못했습니다. 페이지를 새로고침하고 다시 눌러 주세요.")
    return parsed[1]
}
ReadRequest(uri) {
    query := RequestQuery(uri)
    fields := Map()
    for pair in StrSplit(query, "&") {
        parts := StrSplit(pair, "=", , 2)
        if parts.Length = 2 {
            if fields.Has(parts[1])
                throw Error("중복된 요청 항목이 있어 중단했습니다.")
            fields[parts[1]] := Decode(parts[2])
        }
    }
    for key in ["room", "text", "mode", "requestId", "studentKey", "student"]
        if !fields.Has(key)
            fields[key] := key = "student" ? "학생" : ""
    fields["room"] := Trim(fields["room"])
    room := fields["room"], text := fields["text"], mode := fields["mode"]
    if !room || StrLen(room) > 120 || RegExMatch(room, "[\x00-\x1F\x7F]") || StrLen(text) > 12000 || (mode != "test" && mode != "compose" && mode != "send")
        throw Error("대화방 이름과 연결 요청을 확인해 주세요.")
    RegExMatch(Trim(uri), "i)^beolgyo-kakao://([^/?]+)", &route)
    if StrLower(route[1]) != mode
        throw Error("요청 주소와 작업 종류가 달라 중단했습니다.")
    if mode = "send" && (!text || !RegExMatch(fields["requestId"], "^[a-zA-Z0-9_.-]{1,150}$") || !RegExMatch(fields["studentKey"], "^[a-zA-Z0-9_-]{1,500}$"))
        throw Error("자동 전송에 필요한 학생·결과 식별자가 없습니다. 관리자페이지를 새로고침해 주세요.")
    return fields
}
NormalizeMessage(value) {
    return StrReplace(value, "`r", "")
}
HasDifferentDraft(draft, text) {
    return Trim(draft) != "" && draft != "메시지 입력" && NormalizeMessage(draft) != NormalizeMessage(text)
}
RunSelfTests() {
    count := 0
    for test in [
        [Decode("%ED%95%9C%EA%B8%80+%2B+80%25"), "한글 + 80%"],
        [Decode("%F0%9F%98%8A"), "😊"],
        [Decode("a%26b%3Dc%23d%0A"), "a&b=c#d`n"],
        [NormalizeMessage("a`r`nb"), "a`nb"],
        [HasDifferentDraft("", "new"), false],
        [HasDifferentDraft("메시지 입력", "new"), false],
        [HasDifferentDraft("a`r`nb", "a`nb"), false],
        [HasDifferentDraft("old", "new"), true]
    ] {
        if test[1] != test[2]
            throw Error("Self-test comparison failed: " count)
        count += 1
    }
    for uri in ["beolgyo-kakao://compose?mode=compose&room=test", "beolgyo-kakao://compose/?mode=compose&room=test", "BEOLGYO-KAKAO://test/?mode=test&room=test", "beolgyo-kakao://send/?mode=send&room=test&text=hello&requestId=daily-123&studentKey=abc"] {
        ReadRequest(uri)
        count += 1
    }
    for uri in [
        "https://example.com/?room=test&mode=test",
        "beolgyo-kakao://delete?room=test&mode=test",
        "beolgyo-kakao://test?room=test&mode=send",
        "beolgyo-kakao://test?room=&mode=test",
        "beolgyo-kakao://test?room=a%0Ab&mode=test",
        "beolgyo-kakao://test?room=a%09b&mode=test",
        "beolgyo-kakao://test?room=a&room=b&mode=test",
        "beolgyo-kakao://send?room=test&mode=send&text=hello",
        "beolgyo-kakao://send?room=test&mode=send&text=&requestId=1&studentKey=abc",
        "beolgyo-kakao://send?room=test&mode=send&text=hello&requestId=../bad&studentKey=abc",
        "beolgyo-kakao://send?room=test&mode=send&text=hello&requestId=1&studentKey=a%0Ab",
        "beolgyo-kakao://test?room=" StrReplace(Format("{:121}", "x"), " ", "x") "&mode=test"
    ] {
        rejected := false
        try ReadRequest(uri)
        catch
            rejected := true
        if !rejected
            throw Error("Unsafe request was not rejected: test " count)
        count += 1
    }
    return count
}
ChatView(main) {
    online := DllCall("GetDlgItem", "Ptr", main, "Int", 132, "Ptr")
    view := online ? DllCall("GetDlgItem", "Ptr", online, "Int", 1150, "Ptr") : 0
    return view && DllCall("IsWindowVisible", "Ptr", view) ? view : 0
}
SearchEdit(view) {
    edit := DllCall("GetDlgItem", "Ptr", view, "Int", 100, "Ptr")
    return edit && DllCall("IsWindowVisible", "Ptr", edit) && DllCall("IsWindowEnabled", "Ptr", edit) ? edit : 0
}
PrepareSearch(main) {
    Activate(main)
    view := ChatView(main)
    if !view {
        ; Chat rail location in Kakao's standard main window, scaled for its DPI.
        ; Never continue unless the expected chat-list container becomes visible.
        scale := DllCall("GetDpiForWindow", "Ptr", main, "UInt") / 96
        ControlClick("x" Round(32 * scale) " y" Round(115 * scale), "ahk_id " main)
        Loop 15 {
            Sleep 100
            view := ChatView(main)
            if view
                break
        }
    }
    if !view
        throw Error("채팅 목록을 열지 못했습니다. 카카오톡 왼쪽 채팅 아이콘을 누른 뒤 다시 시도해 주세요.")
    edit := SearchEdit(view)
    if !edit {
        ControlFocus(view)
        ; Address the chat-list view directly: the browser can regain foreground
        ; while Windows is finishing the external-app handoff.
        ControlSend("^f", view)
        Loop 15 {
            Sleep 100
            edit := SearchEdit(view)
            if edit
                break
        }
    }
    if !edit
        throw Error("채팅 목록의 검색 입력칸을 확인하지 못했습니다. 채팅 탭에서 검색 아이콘을 누른 뒤 다시 시도해 주세요.")
    ControlFocus(edit)
    return edit
}
AssertEditor(chat, editor) {
    if !WinActive("ahk_id " chat)
        throw Error("입력 중 다른 창으로 이동해 중단했습니다.")
    focused := ControlGetFocus("ahk_id " chat)
    if !focused || ControlGetHwnd(focused, "ahk_id " chat) != editor
        throw Error("대화방 입력칸의 실제 포커스를 확인하지 못해 중단했습니다.")
}
PasteMessage(chat, editor, text) {
    ; WM_SETTEXT can display text without enabling Kakao's Send action.
    ; Use a real paste in the verified foreground editor, preserving the clipboard.
    savedClipboard := ClipboardAll()
    try {
        A_Clipboard := text
        if !ClipWait(1)
            throw Error("메시지 붙여넣기를 준비하지 못했습니다.")
        ControlFocus(editor)
        AssertEditor(chat, editor)
        SendEvent "^a"
        AssertEditor(chat, editor)
        SendEvent "^v"
        Sleep 400
    } finally {
        if A_Clipboard = text
            A_Clipboard := savedClipboard
    }
}
try {
    if A_Args.Length = 1 && A_Args[1] = "--self-test" {
        totalTests := RunSelfTests()
        Status("SELF_TESTS_PASSED=" totalTests " AHK=" A_AhkVersion)
        ExitApp 0
    }
    Status("NATIVE_REQUEST_RECEIVED")
    if A_Args.Length != 1
        throw Error("관리자페이지의 카톡 보내기 버튼에서 실행해 주세요.")
    fields := ReadRequest(A_Args[1])
    room := fields["room"], text := fields["text"], mode := fields["mode"]
    requestId := fields["requestId"], studentKey := fields["studentKey"], student := fields["student"]
    ; Searching or composing must not race with an in-flight send either.
    sendLock := DllCall("CreateMutex", "Ptr", 0, "Int", 1, "Str", "Local\BeolgyoNativeKakaoSend", "Ptr")
    lockError := A_LastError
    if !sendLock
        throw Error("연결 작업 잠금을 준비하지 못했습니다.")
    if lockError = 183 {
        DllCall("CloseHandle", "Ptr", sendLock)
        sendLock := 0
        throw Error("다른 카톡 요청을 처리 중입니다. 잠시 후 다시 눌러 주세요.")
    }
    if mode = "send" {
        allowedRoom := IniRead(A_ScriptDir "\room-links.ini", "Rooms", studentKey, "")
        if allowedRoom != room {
            consent := MsgBox(student " 학생을 다음 대화방에 연결합니다.`n`n" room "`n`n연결 후에는 관리자페이지의 카톡 보내기를 누르면 결과가 자동 입력되고 전송됩니다.`n`n받는 대화방이 정확한가요?", "최초 1회 대화방 연결 확인", "YesNo Icon!")
            if consent != "Yes"
                ExitApp 0
            IniWrite(room, A_ScriptDir "\room-links.ini", "Rooms", studentKey)
        }
        previousAttempt := IniRead(A_ScriptDir "\send-receipts.ini", "Results", requestId, "")
        if previousAttempt != "" {
            if !InStr(previousAttempt, "attempted-")
                throw Error("이미 전송을 요청한 결과입니다. 중복 방지를 위해 다시 보내지 않았습니다.")
            retryConsent := MsgBox("이 결과는 이전 전송의 완료 여부를 확인하지 못했습니다.`n`n받는 방: " room "`n학생: " student "`n`n대화방을 직접 확인하여 같은 결과가 전송되지 않은 것이 확실한 경우에만 [예]를 누르세요. 이미 전송됐다면 [아니요]를 누르세요.", "미확인 전송 1건 재시도 확인", "YesNo Default2 Icon!")
            if retryConsent != "Yes"
                ExitApp 0
        }
    }
    Status("LOCATING_ROOM")
    chat := FindRoom(room)
    if !chat {
        main := FindMain()
        if !main
            throw Error("로그인된 카카오톡 메인창을 찾지 못했습니다. PC 카카오톡의 채팅 목록 창을 열고 로그인 상태를 확인해 주세요.")
        Status("SEARCHING_ROOM")
        search := PrepareSearch(main)
        ControlSetText(room, search)
        Sleep 1000
        if ControlGetText(search) != room || !DllCall("IsWindowVisible", "Ptr", search)
            throw Error("대화방 검색어를 확인하지 못해 중단했습니다.")
        ; Searching is restricted to this verified control, not foreground input.
        ; The destination chat is still verified and activated before any paste.
        if !ChatView(main) || SearchEdit(ChatView(main)) != search
            throw Error("검색 화면이 바뀌어 중단했습니다. 다시 눌러 주세요.")
        ControlFocus(search)
        ControlSend("{Enter}", search)
        Status("WAITING_FOR_EXACT_ROOM")
        Loop 80 {
            Sleep 100
            chat := FindRoom(room)
            if chat
                break
        }
    }
    if !chat
        throw Error("저장한 이름과 일치하는 대화방을 찾지 못했습니다. 정확한 방 이름을 확인해 주세요.")
    Activate(chat)
    Status("NATIVE_ROOM_VERIFIED")
    if (mode = "compose" || mode = "send") && text != "" {
        editor := DllCall("GetDlgItem", "Ptr", chat, "Int", 1006, "Ptr")
        if !editor || !InStr(StrLower(WinGetClass("ahk_id " editor)), "richedit")
            throw Error("대화방 입력칸을 확인하지 못해 중단했습니다.")
        draft := ControlGetText(editor)
        if HasDifferentDraft(draft, text)
            throw Error("입력칸에 작성 중인 문구가 있습니다. 기존 문구를 확인하고 비운 뒤 다시 눌러 주세요. 기존 문구는 덮어쓰지 않았습니다.")
        Status("PASTING_MESSAGE")
        PasteMessage(chat, editor, text)
        if StrReplace(ControlGetText(editor), "`r", "") != StrReplace(text, "`r", "")
            throw Error("입력 결과를 확인하지 못했습니다. 카카오톡 입력창을 확인해 주세요.")
        if mode = "send" {
            if FindRoom(room) != chat || !WinActive("ahk_id " chat)
                throw Error("대화방 확인 중 창이 바뀌어 전송하지 않았습니다.")
            if StrReplace(ControlGetText(editor), "`r", "") != StrReplace(text, "`r", "")
                throw Error("전송 직전 내용이 달라져 중단했습니다.")
            ; Persist before Enter. An uncertain outcome must never cause an automatic retry.
            IniWrite("attempted-" FormatTime(, "yyyyMMddHHmmss"), A_ScriptDir "\send-receipts.ini", "Results", requestId)
            AssertEditor(chat, editor)
            SendEvent "{Enter}"
            cleared := false
            Loop 25 {
                Sleep 100
                remaining := Trim(ControlGetText(editor))
                if remaining = "" || remaining = "메시지 입력" {
                    cleared := true
                    break
                }
            }
            if !cleared
                throw Error("전송키는 요청했지만 완료 여부를 확인하지 못했습니다. 중복 방지를 위해 자동 재시도하지 않습니다. 대화방을 확인해 주세요.")
            IniWrite("submitted-" FormatTime(, "yyyyMMddHHmmss"), A_ScriptDir "\send-receipts.ini", "Results", requestId)
            Status("NATIVE_SEND_SUBMITTED_EDITOR_CLEARED_NOT_DELIVERY_CONFIRMED")
        } else {
            Status("NATIVE_COMPOSED_VERIFIED_NOT_SENT")
        }
    } else {
        Status("NATIVE_ROOM_OPENED_NOT_SENT")
    }
} catch as err {
    ; Do not retain the request lock while an error dialog waits for dismissal.
    if sendLock {
        DllCall("ReleaseMutex", "Ptr", sendLock)
        DllCall("CloseHandle", "Ptr", sendLock)
        sendLock := 0
    }
    try Status("ERROR " err.Message)
    if A_Args.Length = 1 && A_Args[1] = "--self-test"
        ExitApp 1
    MsgBox(err.Message, "벌교미래엔영어 카톡 연결", "Icon!")
    ExitApp 1
}
ExitApp 0
