﻿$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('DesktopDirectory')
$installDir = Join-Path $desktop '학원관리\카카오톡연결'
New-Item -ItemType Directory -Path $installDir -Force | Out-Null
$runtime = Join-Path $installDir 'AutoHotkey64.exe'
if (-not (Test-Path -LiteralPath $runtime)) {
    $archive = Join-Path $installDir 'official-autohotkey.zip'
    Invoke-WebRequest -Uri 'https://www.autohotkey.com/download/ahk-v2.zip' -OutFile $archive -UseBasicParsing
    $expected = 'CA1A595ACA4528755D8D4CD7FED23D497A37BD9A0B6892072612D68DEE1BD00A'
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $expected) {
        throw 'Official runtime version changed. Please request an updated installer.'
    }
    $vendor = Join-Path $installDir 'vendor'
    Expand-Archive -LiteralPath $archive -DestinationPath $vendor -Force
    Copy-Item -LiteralPath (Join-Path $vendor 'AutoHotkey64.exe') -Destination $runtime -Force
    Copy-Item -LiteralPath (Join-Path $vendor 'license.txt') -Destination (Join-Path $installDir 'AutoHotkey-license.txt') -Force
}
$script = Join-Path $installDir 'kakao-connect.ahk'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'kakao-connect.ahk') -Destination $script -Force
# A dedicated executable identity avoids relying on missing version-resource
# display names and does not change registration for unrelated AutoHotkey apps.
$connector = Join-Path $installDir 'BeolgyoKakaoConnector.exe'
Copy-Item -LiteralPath $runtime -Destination $connector -Force
$application = 'HKCU:\Software\Classes\Applications\BeolgyoKakaoConnector.exe'
New-Item -Path $application -Force | Out-Null
Set-ItemProperty -Path $application -Name 'FriendlyAppName' -Value 'Beolgyo Kakao PC Connector'
New-Item -Path "$application\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$application\shell\open\command" -Name '(Default)' -Value ('"' + $connector + '" "' + $script + '" "%1"')
$root = 'HKCU:\Software\Classes\beolgyo-kakao'
New-Item -Path $root -Force | Out-Null
Set-ItemProperty -Path $root -Name '(Default)' -Value 'URL:Beolgyo Kakao PC Connector'
Set-ItemProperty -Path $root -Name 'URL Protocol' -Value ''
New-Item -Path "$root\Application" -Force | Out-Null
Set-ItemProperty -Path "$root\Application" -Name 'ApplicationName' -Value 'Beolgyo Kakao PC Connector'
New-Item -Path "$root\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$root\shell\open\command" -Name '(Default)' -Value ('"' + $connector + '" "' + $script + '" "%1"')
# Offer a Windows Default Apps candidate; the user chooses it in Settings.
# Never fabricate UserChoice hashes or bypass browser external-app consent.
$progId = 'HKCU:\Software\Classes\BeolgyoKakaoConnector.Url'
New-Item -Path "$progId\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path $progId -Name '(Default)' -Value 'Beolgyo Kakao PC Connector'
Set-ItemProperty -Path $progId -Name 'URL Protocol' -Value ''
Set-ItemProperty -Path "$progId\shell\open\command" -Name '(Default)' -Value ('"' + $connector + '" "' + $script + '" "%1"')
New-Item -Path "$progId\Application" -Force | Out-Null
Set-ItemProperty -Path "$progId\Application" -Name 'ApplicationName' -Value 'Beolgyo Kakao PC Connector'
$capabilities = 'HKCU:\Software\BeolgyoKakaoConnector\Capabilities'
New-Item -Path "$capabilities\UrlAssociations" -Force | Out-Null
Set-ItemProperty -Path $capabilities -Name 'ApplicationName' -Value 'Beolgyo Kakao PC Connector'
Set-ItemProperty -Path $capabilities -Name 'ApplicationDescription' -Value 'Opens the Beolgyo academy Kakao PC connector after a user clicks a beolgyo-kakao link.'
Set-ItemProperty -Path "$capabilities\UrlAssociations" -Name 'beolgyo-kakao' -Value 'BeolgyoKakaoConnector.Url'
New-Item -Path 'HKCU:\Software\RegisteredApplications' -Force | Out-Null
Set-ItemProperty -Path 'HKCU:\Software\RegisteredApplications' -Name 'Beolgyo Kakao PC Connector' -Value 'Software\BeolgyoKakaoConnector\Capabilities'
# Notify the Shell about the new association. This does not launch a URI,
# alter browser consent, or choose a default browser.
if (-not ('BeolgyoAssociationNotification' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class BeolgyoAssociationNotification {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(int eventId, uint flags, IntPtr item1, IntPtr item2);
}
'@
}
[BeolgyoAssociationNotification]::SHChangeNotify(0x08000000, 0x1000, [IntPtr]::Zero, [IntPtr]::Zero)
Write-Output 'Installed native Kakao connector. No .NET runtime is required.'
Write-Output 'Windows association refresh notified. Close and reopen Edge/Chrome before testing.'

